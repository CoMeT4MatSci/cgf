#!/bin/bash
#SBATCH --time=00:30:00
#SBATCH -J Check
#SBATCH -o out
#SBATCH -e err
#SBATCH -n 4
#SBATCH --mem-per-cpu=1500M

echo $PWD

export ASE_DFTB_COMMAND="/sw/installed/DFTB+/18.2-intel-2018a-Python-2.7.14/bin/dftb+ > dftb.out"
export DFTB_PREFIX=/home/dabo814c/lib/slako/matsci/matsci-0-3/

module load modenv/scs5
module load DFTB+/18.2-intel-2018a-Python-2.7.14
module load ASE/3.19.0-fosscuda-2019b-Python-3.7.4


python ../calc_elastic.py $PWD dftb
